const Charge = () =>{

    return(
    <div className="Charge">
      수수료 정보,표 게시
    </div>
    );






}

export default Charge;