package com.travel.booking.domain.booking;

public enum OrderStatus {

    ORDERED, CANCELED, WAITING
}
