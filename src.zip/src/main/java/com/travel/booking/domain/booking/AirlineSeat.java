package com.travel.booking.domain.booking;

public enum AirlineSeat {
    WINDOW, LEGROOM, RANDOM;
}
