package com.travel.booking.domain.booking;

public enum TransportationType {
    TRAIN, AIRLINE, BUS;
}
