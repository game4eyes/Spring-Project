package com.travel.booking.domain.user;

public enum Role {

    USER, ADMIN;
}
