package com.travel.booking.domain.odsay.city.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CityInfoDTO {
    private String cityCode;
    private String cityName;
}
