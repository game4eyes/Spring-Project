package com.travel.booking.domain.booking;

public class BookingRepo {


}