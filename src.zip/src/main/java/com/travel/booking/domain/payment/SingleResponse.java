package com.travel.booking.domain.payment;

public class SingleResponse<T> {
    public SingleResponse(PaymentResDTO paymentResDTO) {
    }
}
