package com.travel.booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBookingApplicationTests {

    @Test
    void contextLoads() {
    }

}
